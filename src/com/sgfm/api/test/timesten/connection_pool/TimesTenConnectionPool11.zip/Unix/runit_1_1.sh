#!/bin/bash
java -cp ..:../ttcp.jar:$CLASSPATH% TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 1 -pool 1 -reads 100 -xacts 5000000 -nobuild
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 2 -pool 1 -reads 100 -xacts 5000000 -nobuild
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 4 -pool 1 -reads 100 -xacts 2000000 -nobuild
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 8 -pool 1 -reads 100 -xacts 1000000 -nobuild
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 16 -pool 1 -reads 100 -xacts 500000 -nobuild
