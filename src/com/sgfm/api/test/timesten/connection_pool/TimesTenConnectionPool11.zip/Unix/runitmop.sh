#!/bin/bash
java -cp ..:../ttcp.jar:%CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 1 -pool 1 -xacts 200000 -multiop >mop1.txt
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 2 -pool 1 -xacts 200000 -multiop >>mop1.txt
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 4 -pool 1 -xacts 200000 -multiop >>mop1.txt
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 1 -pool 2 -xacts 200000 -multiop >mop2.txt
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 2 -pool 2 -xacts 200000 -multiop >>mop2.txt
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 4 -pool 2 -xacts 200000 -multiop >>mop2.txt
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 1 -pool 4 -xacts 200000 -multiop >mop4.txt
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 2 -pool 4 -xacts 200000 -multiop >>mop4.txt
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 4 -pool 4 -xacts 200000 -multiop >>mop4.txt
./builddb.sh
