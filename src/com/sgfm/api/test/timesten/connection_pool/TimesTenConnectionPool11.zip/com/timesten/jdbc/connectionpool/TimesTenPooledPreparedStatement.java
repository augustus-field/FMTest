package com.timesten.jdbc.connectionpool;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;
import java.net.URL;
import java.sql.*;
import com.timesten.jdbc.*;

/**
 * Represents a TimesTen prepared statement.
 *
 * This class should not be instantiated directly. Instances of this classs
 * are manipulated via methods in the associated TimesTenPooledConnection and
 * TimesTenConnectionPool classes.
 * <p><p>
 * This class implements the standard PreparedStatement interface, plus 
 * some additional methods.
 * <p><p>
 * Any methods which are not explicitly documented behave identically to
 * the corresponding method in TimesTenPreparedStatement.
 * <p><p>
 * Any individual instance of this class should not be shared amongst multiple 
 * threads.
 * <p><p>
 * If the connection that owns this statement has been invalidated due to a 
 * failover most methods will throw a TTCP_ERR_STMT_INVALID exception.
 */
public final class TimesTenPooledPreparedStatement 
	implements TimesTenPreparedStatement
{
    ///////////////////// CONSTANTS //////////////////
    //
    // Classname
    private static final String className = "TimesTenPooledPreparedStatement";

    ///////////////////// PRIVATE VARIABLES //////////////////

    // Lock for things that affect the connection
    private ReentrantLock stmtLock = null;   

    // The underlying prepared statement for this 
    // TimesTenPreparedStatement
    private TimesTenPreparedStatement pStmt = null;

    // The 'label' for this statement
    private String stmtLabel = null;

    // The SQL statement that this represents
    private String sqlText = null;

    // Optimiser hints for this statement
    private String[] optHints = null;

    // The TimesTenPooledConnection that 'owns' this TimesTenPooledPreparedStatement
    private TimesTenPooledConnection stmtConn = null;

    // The TimesTenConnectionPool that ultimately 'owns' this TimesTenPooledPreparedStatement
    private TimesTenConnectionPool stmtPool = null;

    // Flags for state of statement
    private boolean isPrepared = false;

    // Is statement invalid due to failover
    private boolean isDefunct = false;

    ///////////////////// CONSTRUCTORS /////////////////////////
    
    // Create a prepared statement with the specified label on the given 
    // connection
    protected TimesTenPooledPreparedStatement(
		                        TimesTenConnectionPool pool, 
		                        TimesTenPooledConnection conn, 
		                        String label, 
		                        String sql) 
	    throws SQLException
    {
	this.stmtConn = conn;
	this.stmtPool = pool;
	this.stmtLabel = label;
	this.sqlText = sql;
	this.optHints = null;
        stmtLock = new ReentrantLock(stmtPool.getLockingFairness());
	prepareSQL();
    }

    // Create a prepared statement with the specified label on the given 
    // connection, applying the specified optimiser hints
    protected TimesTenPooledPreparedStatement(
		                        TimesTenConnectionPool pool, 
		                        TimesTenPooledConnection conn, 
		                        String label, 
		                        String sql, 
					String[] opthints) 
	    throws SQLException
    {
	this.stmtConn = conn;
	this.stmtPool = pool;
	this.stmtLabel = label;
	this.sqlText = sql;
	this.optHints = opthints;
        stmtLock = new ReentrantLock(stmtPool.getLockingFairness());
	prepareSQL();
    }

    ////////////// FINALIZER /////////////

    protected void finalize()
	    throws Throwable
    {
        stmtLabel = null;
        sqlText = null;
        optHints = null;
        stmtConn = null;
        stmtPool = null;
	if (  this.pStmt != null  )
	    try {
	       pStmt.close();
	    } catch ( SQLException e ) {
		// ignore it
	    }
	super.finalize();
    }

    //////////////////// PRIVATE METHODS ///////////////////////
 
    // lock the statement
    private final void lockStmt()
    {
	this.stmtLock.lock();
    }

    // unlock the statement
    private final void unlockStmt()
    {
	this.stmtLock.unlock();
    }

    // Check if statement is locked
    private final boolean isStmtLocked()
    {
	return this.stmtLock.isLocked();
    }

    // Handle defunct statement
    private final void checkDefunct(String funcname)
	    throws SQLException
    {
	if (  this.isDefunct  )
	    throw new SQLException(
	        className + funcname + ":statement invalid due to failover",
		TimesTenConnectionPool.TTCP_SQLSTATE,
		TimesTenConnectionPool.TTCP_ERR_STMT_INVALID);
    }
    
    // Prepare a statement - only called from constructors
    private final void prepareSQL() 
	    throws SQLException
    {
	checkDefunct("prepareSQL");

	if (  this.optHints != null  )
	{
	    Statement stmt = this.stmtConn.getNativeConnection().createStatement();
	    try {
	        for (int i=0; i < this.optHints.length; i++)
                    stmt.execute(this.optHints[i]);
	    } catch ( SQLException e  ) {
		this.stmtConn.commit();
		throw e;
	    } finally {
	        stmt.close();
	    }
	}
	try {
	    this.pStmt = this.stmtConn.nativePrepare(this.sqlText);
	} finally {
	    this.stmtConn.commit();
	}
	this.isPrepared = true;
    }

    //////////////////// PROTECTED METHODS ///////////////////////
    
    // Close this prepared statement.
    protected final void realClose() 
	    throws SQLException
    {
	lockStmt();
	try {
	    if (  !this.isDefunct  )
	        try {
	            pStmt.close();
	        } finally {
	            this.isPrepared = false;
	        }
	} finally {
            unlockStmt();
        }
    }

    // Set the isDefunct flag
    protected final void setIsDefunct(boolean isdefunct)
    {
	this.isDefunct = isdefunct;
    }

    // Get the isDefunct flag
    protected final boolean isDefunct()
    {
	return this.isDefunct;
    }
 
    ////////////////// ADDITIONAL PUBLIC METHODS /////////////////////
    
    /**
     * Returns the textual label associated with this statement.
     * The label is defined when the statement is created via one
     * of the addPreparedStatement() methods in the
     * TimesTenPooledConnection class.
     */
    public final String getLabel()
    {
	return this.stmtLabel;
    }
    
    /**
     * Returns the SQL text for this prepared statement.
     * This can be useful for debugging or tracing.
     */
    public final String getSql()
    {
	return this.sqlText;
    }

    /**
     * Returns the array of optimiser hints used when preparing this statement.
     * This can be useful for debugging or tracing. If no hints were used
     * (the usual case) then returns null.
     */
    public final String[] getOptHints()
    {
	return this.optHints;
    }

    ////////////////// OVERRIDDEN METHODS //////////////////////////

    /**
     * Always returns false.
     * Statement pooling is not required and so is not supported.
     */
    public final boolean isPoolable() // from Statement
    {
	return false; // we don't support statement pooling (no need)
    }

    /**
     * Silently does nothing.
     * Statement pooling is not required and so is not supported.
     */
    public final void setPoolable(boolean poolable) // from Statement
    {
	// silently do nothing - we don't support statement pooling
    }

    /**
     * Returns the TimesTenPooledConnection (as a Connection) with
     * which this TimesTenPooledPreparedStatement is associated.
     */
    public final Connection getConnection() 
    {
	return this.stmtConn;
    }

    /**
     * Indicates if statement is 'closed'.
     * 'closed' means 'not prepared'.
     */
    public final boolean isClosed() 
    {
	return !this.isPrepared;
    }

    /**
     * Silently does nothing.
     * A TimesTenPooledPreparedStatement can only be closed by the owning
     * TimesTenPooledConnection object which in turn will only close
     * the statement when directed to by its owning TimestenConnectionPool
     * object, via the removePreparedStatement() method.
     */
    public final void close() 
    {
	// Silently do nothing.
	// Only the owning connection can close the statement
	// via the realClose() method.
    }
 
    ////////////////////////////////////////////////////////////////////////
    //               NOTHING INTERESTING BEYOND THIS POINT                //
    //                                                                    //
    // All the following methods pretty much just call the corresponding  //
    // method in the associated TimesTenPreparedStatement object.         //
    ////////////////////////////////////////////////////////////////////////

    // Methods from TimesTenPreparedStatement
    
    /**
     * See com.timesten.jdbc.TimesTenPreparedStatement.registerReturnParameter()
     */
    public final void registerReturnParameter(int paramIndex, int sqlType)
	    throws SQLException
    {
	checkDefunct("registerReturnParameter");

	pStmt.registerReturnParameter(paramIndex, sqlType);
    }
    
    /**
     * See com.timesten.jdbc.TimesTenPreparedStatement.registerReturnParameter()
     */
    public final void registerReturnParameter(int paramIndex, int sqlType,
		                              int maxSize)
	    throws SQLException
    {
	checkDefunct("registerReturnParameter");

	pStmt.registerReturnParameter(paramIndex, sqlType, maxSize);
    }
    
    /**
     * See com.timesten.jdbc.TimesTenPreparedStatement.getReturnedResultSet()
     */
    public final ResultSet getReturnResultSet() 
	    throws SQLException
    {
	checkDefunct("getReturnResultSet");

	return pStmt.getReturnResultSet();
    }
    
    // Methods from PreparedStatement
    
    /**
     * See java.sql.PreparedStatement.getResultSet()
     */
    public final ResultSet getResultSet() 
	    throws SQLException
    {
	checkDefunct("getResultSet");

	return pStmt.getResultSet();
    }
    
    /**
     * See java.sql.PreparedStatement.execute()
     */
    public final boolean execute() 
	    throws SQLException
    {
	checkDefunct("execute");

	this.stmtConn.setInTxn(true);
	return pStmt.execute();
    }

    /**
     * See java.sql.PreparedStatement.executeQuery()
     */
    public final ResultSet executeQuery() 
	    throws SQLException
    {
	checkDefunct("executeQuery");

	this.stmtConn.setInTxn(true);
	return pStmt.executeQuery();
    }

    /**
     * See java.sql.PreparedStatement.executeUpdate()
     */
    public final int executeUpdate() 
	    throws SQLException
    {
	checkDefunct("executeUpdate");

	this.stmtConn.setInTxn(true);
	return pStmt.executeUpdate();
    }

    /**
     * See java.sql.PreparedStatement.addbatch()
     */
    public final void addBatch() 
	    throws SQLException
    {
	checkDefunct("addBatch");

	pStmt.addBatch();
    }

    /**
     * See java.sql.PreparedStatement.clearParameters()
     */
    public final void clearParameters() 
	    throws SQLException
    {
	checkDefunct("clearParameters");

	pStmt.clearParameters();
    }

    /**
     * See java.sql.PreparedStatement.getMetaData()
     */
    public final ResultSetMetaData getMetaData() 
	    throws SQLException
    {
	checkDefunct("getMetaData");

	return pStmt.getMetaData();
    }

    /**
     * See java.sql.PreparedStatement.getParameterMetaData()
     */
    public final ParameterMetaData getParameterMetaData() 
	    throws SQLException
    {
	checkDefunct("getParameterMetaData");

	return pStmt.getParameterMetaData();
    }

    /**
     * See java.sql.PreparedStatement.setArray()
     */
    public final void setArray(int parameterIndex, Array x) 
	    throws SQLException
    {
	checkDefunct("setArray");

	pStmt.setArray(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setAsciiStream()
     */
    public final void setAsciiStream(int parameterIndex, InputStream x) 
	    throws SQLException
    {
	checkDefunct("setAsciiStream");

	pStmt.setAsciiStream(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setAsciiStream()
     */
    public final void setAsciiStream(int parameterIndex, InputStream x, int length) 
	    throws SQLException
    {
	checkDefunct("setAsciiStream");

	pStmt.setAsciiStream(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setAsciiStream()
     */
    public final void setAsciiStream(int parameterIndex, InputStream x, long length) 
	    throws SQLException
    {
	checkDefunct("setAsciiStream");

	pStmt.setAsciiStream(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setBigDecimal()
     */
    public final void setBigDecimal(int parameterIndex, BigDecimal x) 
	    throws SQLException
    {
	checkDefunct("setBigDecimal");

	pStmt.setBigDecimal(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setBinaryStream()
     */
    public final void setBinaryStream(int parameterIndex, InputStream x) 
	    throws SQLException
    {
	checkDefunct("setBinaryStream");

	pStmt.setBinaryStream(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setBinaryStream()
     */
    public final void setBinaryStream(int parameterIndex, InputStream x, int length) 
	    throws SQLException
    {
	checkDefunct("setBinaryStream");

	pStmt.setBinaryStream(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setBinaryStream()
     */
    public final void setBinaryStream(int parameterIndex, InputStream x, long length) 
	    throws SQLException
    {
	checkDefunct("setBinaryStream");

	pStmt.setBinaryStream(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setBlob()
     */
    public final void setBlob(int parameterIndex, Blob x) 
	    throws SQLException
    {
	checkDefunct("setBlob");

	pStmt.setBlob(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setBlob()
     */
    public final void setBlob(int parameterIndex, InputStream x) 
	    throws SQLException
    {
	checkDefunct("setBlob");

	pStmt.setBlob(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setBlob()
     */
    public final void setBlob(int parameterIndex, InputStream x, long length) 
	    throws SQLException
    {
	checkDefunct("setBlob");

	pStmt.setBlob(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setBoolean()
     */
    public final void setBoolean(int parameterIndex, boolean x) 
	    throws SQLException
    {
	checkDefunct("setBoolean");

	pStmt.setBoolean(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setByte()
     */
    public final void setByte(int parameterIndex, byte x) 
	    throws SQLException
    {
	checkDefunct("setByte");

	pStmt.setByte(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setBytes()
     */
    public final void setBytes(int parameterIndex, byte[] x) 
	    throws SQLException
    {
	checkDefunct("setBytes");

	pStmt.setBytes(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setCharacterStream()
     */
    public final void setCharacterStream(int parameterIndex, Reader x) 
	    throws SQLException
    {
	checkDefunct("setCharacterStream");

	pStmt.setCharacterStream(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setCharacterStream()
     */
    public final void setCharacterStream(int parameterIndex, Reader x, int length) 
	    throws SQLException
    {
	checkDefunct("setCharacterStream");

	pStmt.setCharacterStream(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setCharacterStream()
     */
    public final void setCharacterStream(int parameterIndex, Reader x, long length) 
	    throws SQLException
    {
	checkDefunct("setCharacterStream");

	pStmt.setCharacterStream(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setClob()
     */
    public final void setClob(int parameterIndex, Clob x) 
	    throws SQLException
    {
	checkDefunct("setClob");

	pStmt.setClob(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setClob()
     */
    public final void setClob(int parameterIndex, Reader x) 
	    throws SQLException
    {
	checkDefunct("setClob");

	pStmt.setClob(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setClob()
     */
    public final void setClob(int parameterIndex, Reader x, long length) 
	    throws SQLException
    {
	checkDefunct("setClob");

	pStmt.setClob(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setDate()
     */
    public final void setDate(int parameterIndex, Date x) 
	    throws SQLException
    {
	checkDefunct("setDate");

	pStmt.setDate(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setDate()
     */
    public final void setDate(int parameterIndex, Date x, Calendar cal) 
	    throws SQLException
    {
	checkDefunct("setDate");

	pStmt.setDate(parameterIndex, x, cal);
    }

    /**
     * See java.sql.PreparedStatement.setDouble()
     */
    public final void setDouble(int parameterIndex, double x) 
	    throws SQLException
    {
	checkDefunct("setDouble");

	pStmt.setDouble(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setFloat()
     */
    public final void setFloat(int parameterIndex, float x) 
	    throws SQLException
    {
	checkDefunct("setFloat");

	pStmt.setFloat(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setInt()
     */
    public final void setInt(int parameterIndex, int x) 
	    throws SQLException
    {
	checkDefunct("setInt");

	pStmt.setInt(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setLong()
     */
    public final void setLong(int parameterIndex, long x) 
	    throws SQLException
    {
	checkDefunct("setLong");

	pStmt.setLong(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setNCharacterStream()
     */
    public final void setNCharacterStream(int parameterIndex, Reader x) 
	    throws SQLException
    {
	checkDefunct("setNCharacterStream");

	pStmt.setNCharacterStream(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setNCharacterStream()
     */
    public final void setNCharacterStream(int parameterIndex, Reader x, long length) 
	    throws SQLException
    {
	checkDefunct("setNCharacterStream");

	pStmt.setNCharacterStream(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setNClob()
     */
    public final void setNClob(int parameterIndex, NClob x) 
	    throws SQLException
    {
	checkDefunct("setNClob");

	pStmt.setNClob(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setNClob()
     */
    public final void setNClob(int parameterIndex, Reader x) 
	    throws SQLException
    {
	checkDefunct("setNClob");

	pStmt.setNClob(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setNClob()
     */
    public final void setNClob(int parameterIndex, Reader x, long length) 
	    throws SQLException
    {
	checkDefunct("setNClob");

	pStmt.setNClob(parameterIndex, x, length);
    }

    /**
     * See java.sql.PreparedStatement.setNString()
     */
    public final void setNString(int parameterIndex, String x) 
	    throws SQLException
    {
	checkDefunct("setNString");

	pStmt.setNString(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setNull()
     */
    public final void setNull(int parameterIndex, int sqlType) 
	    throws SQLException
    {
	checkDefunct("setNull");

	pStmt.setNull(parameterIndex, sqlType);
    }

    /**
     * See java.sql.PreparedStatement.setNull()
     */
    public final void setNull(int parameterIndex, int sqlType, String typeName) 
	    throws SQLException
    {
	checkDefunct("setNull");

	pStmt.setNull(parameterIndex, sqlType, typeName);
    }

    /**
     * See java.sql.PreparedStatement.setObject()
     */
    public final void setObject(int parameterIndex, Object x) 
	    throws SQLException
    {
	checkDefunct("setObject");

	pStmt.setObject(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setObject()
     */
    public final void setObject(int parameterIndex, Object x, int targetSqlType) 
	    throws SQLException
    {
	checkDefunct("setObject");

	pStmt.setObject(parameterIndex, x, targetSqlType);
    }

    /**
     * See java.sql.PreparedStatement.setObject()
     */
    public final void setObject(int parameterIndex, Object x, int targetSqlType,
		          int scaleOrLength) 
	    throws SQLException
    {
	checkDefunct("setObject");

	pStmt.setObject(parameterIndex, x, targetSqlType, scaleOrLength);
    }

    /**
     * See java.sql.PreparedStatement.setRef()
     */
    public final void setRef(int parameterIndex, Ref x) 
	    throws SQLException
    {
	checkDefunct("setRef");

	pStmt.setRef(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setRowid()
     */
    public final void setRowId(int parameterIndex, RowId x) 
	    throws SQLException
    {
	checkDefunct("setRowId");

	pStmt.setRowId(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setShort()
     */
    public final void setShort(int parameterIndex, short x) 
	    throws SQLException
    {
	checkDefunct("setShort");

	pStmt.setShort(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setSQLXML()
     */
    public final void setSQLXML(int parameterIndex, SQLXML x) 
	    throws SQLException
    {
	checkDefunct("setSQLXML");

	pStmt.setSQLXML(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setString()
     */
    public final void setString(int parameterIndex, String x) 
	    throws SQLException
    {
	checkDefunct("setString");

	pStmt.setString(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setTime()
     */
    public final void setTime(int parameterIndex, Time x) 
	    throws SQLException
    {
	checkDefunct("setTime");

	pStmt.setTime(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setTime()
     */
    public final void setTime(int parameterIndex, Time x, Calendar cal) 
	    throws SQLException
    {
	checkDefunct("setTime");

	pStmt.setTime(parameterIndex, x, cal);
    }

    /**
     * See java.sql.PreparedStatement.setTimestamp()
     */
    public final void setTimestamp(int parameterIndex, Timestamp x) 
	    throws SQLException
    {
	checkDefunct("setTimestamp");

	pStmt.setTimestamp(parameterIndex, x);
    }

    /**
     * See java.sql.PreparedStatement.setTimestamp()
     */
    public final void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) 
	    throws SQLException
    {
	checkDefunct("setTimestamp");

	pStmt.setTimestamp(parameterIndex, x, cal);
    }

    /**
     * See java.sql.PreparedStatement.setURL()
     */
    public final void setURL(int parameterIndex, URL x) 
	    throws SQLException
    {
	checkDefunct("setURL");

	pStmt.setURL(parameterIndex, x);
    }

    // Deprecated
    /**
     * See java.sql.PreparedStatement.setUnicodeStream() - DEPRECATED
     */
    public final void setUnicodeStream(int parameterIndex, InputStream x, int length) 
	    throws SQLException
    {
	checkDefunct("setUnicodeStream");

	pStmt.setUnicodeStream(parameterIndex, x, length);
    }

    // Methods from Statement

    /**
     * See java.sql.Statement.addBatch()
     */
    public final void addBatch(String sql) 
	    throws SQLException
    {
	checkDefunct("addBatch");

	pStmt.addBatch(sql);
    }

    /**
     * See java.sql.Statement.cancel()
     */
    public final void cancel() 
	    throws SQLException
    {
	checkDefunct("cancel");

	pStmt.cancel();
    }

    /**
     * See java.sql.Statement.clearBatch()
     */
    public final void clearBatch() 
	    throws SQLException
    {
	checkDefunct("clearBatch");

	pStmt.clearBatch();
    }

    /**
     * See java.sql.Statement.clearWarnings()
     */
    public final void clearWarnings() 
	    throws SQLException
    {
	checkDefunct("clearWarnings");

	pStmt.clearWarnings();
    }

    /**
     * See java.sql.Statement.execute()
     */
    public final boolean execute(String sql) 
	    throws SQLException
    {
	checkDefunct("execute");

	this.stmtConn.setInTxn(true);
	return pStmt.execute(sql);
    }
 
    /**
     * See java.sql.Statement.execute()
     */
    public final boolean execute(String sql, int autoGeneratedKeys) 
	    throws SQLException
    {
	checkDefunct("execute");

	this.stmtConn.setInTxn(true);
	return pStmt.execute(sql, autoGeneratedKeys);
    }
 
    /**
     * See java.sql.Statement.execute()
     */
    public final boolean execute(String sql, int[] columnIndexes) 
	    throws SQLException
    {
	checkDefunct("execute");

	this.stmtConn.setInTxn(true);
	return pStmt.execute(sql, columnIndexes);
    }
 
    /**
     * See java.sql.Statement.execute()
     */
    public final boolean execute(String sql, String[] columnNames) 
	    throws SQLException
    {
	checkDefunct("execute");

	this.stmtConn.setInTxn(true);
	return pStmt.execute(sql, columnNames);
    }

    /**
     * See java.sql.Statement.executeBatch()
     */
    public final int[] executeBatch() 
	    throws SQLException
    {
	checkDefunct("executeBatch");

	this.stmtConn.setInTxn(true);
	return pStmt.executeBatch();
    }
 
    /**
     * See java.sql.Statement.executeQuery()
     */
    public final ResultSet executeQuery(String sql) 
	    throws SQLException
    {
	checkDefunct("executeQuery");

	this.stmtConn.setInTxn(true);
	return pStmt.executeQuery(sql);
    }
 
    /**
     * See java.sql.Statement.executeUpdate()
     */
    public final int executeUpdate(String sql) 
	    throws SQLException
    {
	checkDefunct("executeUpdate");

	this.stmtConn.setInTxn(true);
	return pStmt.executeUpdate(sql);
    }
 
    /**
     * See java.sql.Statement.executeUpdate()
     */
    public final int executeUpdate(String sql, int autoGeneratedKeys) 
	    throws SQLException
    {
	checkDefunct("executeUpdate");

	this.stmtConn.setInTxn(true);
	return pStmt.executeUpdate(sql, autoGeneratedKeys);
    }
 
    /**
     * See java.sql.Statement.executeUpdate()
     */
    public final int executeUpdate(String sql, int[] columnIndexes) 
	    throws SQLException
    {
	checkDefunct("executeUpdate");

	this.stmtConn.setInTxn(true);
	return pStmt.executeUpdate(sql, columnIndexes);
    }
 
    /**
     * See java.sql.Statement.executeUpdate()
     */
    public final int executeUpdate(String sql, String[] columnNames) 
	    throws SQLException
    {
	checkDefunct("executeUpdate");

	this.stmtConn.setInTxn(true);
	return pStmt.executeUpdate(sql, columnNames);
    }
 
    /**
     * See java.sql.Statement.getFetchDirection()
     */
    public final int getFetchDirection() 
	    throws SQLException
    {
	return pStmt.getFetchDirection();
    }
 
    /**
     * See java.sql.Statement.getFetchSize()
     */
    public final int getFetchSize() 
	    throws SQLException
    {
	checkDefunct("getFetchSize");

	return pStmt.getFetchSize();
    }
 
    /**
     * See java.sql.Statement.getGeneratedKeys()
     */
    public final ResultSet getGeneratedKeys() 
	    throws SQLException
    {
	checkDefunct("getFetchSize");

	return pStmt.getGeneratedKeys();
    }
 
    /**
     * See java.sql.Statement.getMaxFieldSize()
     */
    public final int getMaxFieldSize() 
	    throws SQLException
    {
	checkDefunct("getMaxFieldSize");

	return pStmt.getMaxFieldSize();
    }
 
    /**
     * See java.sql.Statement.getMaxRows()
     */
    public final int getMaxRows() 
	    throws SQLException
    {
	checkDefunct("getMaxRows");

	return pStmt.getMaxRows();
    }
 
    /**
     * See java.sql.Statement.getMoreResults()
     */
    public final boolean getMoreResults() 
	    throws SQLException
    {
	checkDefunct("getMoreResults");

	return pStmt.getMoreResults();
    }

    /**
     * See java.sql.Statement.getMoreResults()
     */
    public final boolean getMoreResults(int current) 
	    throws SQLException
    {
	checkDefunct("getMoreResults");

	return pStmt.getMoreResults(current);
    }
 
    /**
     * See java.sql.Statement.getQueryTimeout()
     */
    public final int getQueryTimeout() 
	    throws SQLException
    {
	checkDefunct("getQueryTimeout");

	return pStmt.getQueryTimeout();
    }
 
    /**
     * See java.sql.Statement.getResultSetConcurrency()
     */
    public final int getResultSetConcurrency() 
	    throws SQLException
    {
	checkDefunct("getResultSetConcurrency");

	return pStmt.getResultSetConcurrency();
    }
 
    /**
     * See java.sql.Statement.getResultSetHoldability()
     */
    public final int getResultSetHoldability() 
	    throws SQLException
    {
	checkDefunct("getResultSetHoldability");

	return pStmt.getResultSetHoldability();
    }
 
    /**
     * See java.sql.Statement.getResultSetType()
     */
    public final int getResultSetType() 
	    throws SQLException
    {
	checkDefunct("getResultSetType");

	return pStmt.getResultSetType();
    }
 
    /**
     * See java.sql.Statement.getUpdateCount()
     */
    public final int getUpdateCount() 
	    throws SQLException
    {
	checkDefunct("getUpdateCount");

	return pStmt.getUpdateCount();
    }

    /**
     * See java.sql.Statement.getWarnings()
     */
    public final SQLWarning getWarnings() 
	    throws SQLException
    {
	checkDefunct("getWarnings");

	return pStmt.getWarnings();
    }

    /**
     * See java.sql.Statement.setCursorName()
     */
    public final void setCursorName(String name) 
	    throws SQLException
    {
	checkDefunct("setCursorName");

	pStmt.setCursorName(name);
    }

    /**
     * See java.sql.Statement.setEscapeProcessing()
     */
    public final void setEscapeProcessing(boolean enable) 
	    throws SQLException
    {
	checkDefunct("setEscapeProcessing");

	pStmt.setEscapeProcessing(enable);
    }

    /**
     * See java.sql.Statement.setFetchDirection()
     */
    public final void setFetchDirection(int direction) 
	    throws SQLException
    {
	checkDefunct("setFetchDirection");

	pStmt.setFetchDirection(direction);
    }

    /**
     * See java.sql.Statement.setFetchSize()
     */
    public final void setFetchSize(int rows) 
	    throws SQLException
    {
	checkDefunct("setFetchSize");

	pStmt.setFetchSize(rows);
    }

    /**
     * See java.sql.Statement.setMaxFieldSize()
     */
    public final void setMaxFieldSize(int max) 
	    throws SQLException
    {
	checkDefunct("setMaxFieldSize");

	pStmt.setMaxFieldSize(max);
    }

    /**
     * See java.sql.Statement.setMaxRows()
     */
    public final void setMaxRows(int rows) 
	    throws SQLException
    {
	checkDefunct("setMaxRows");

	pStmt.setMaxRows(rows);
    }

    /**
     * See java.sql.Statement.setQueryTimeout()
     */
    public final void setQueryTimeout(int seconds) 
	    throws SQLException
    {
	checkDefunct("setQueryTimeout");

	pStmt.setQueryTimeout(seconds);
    }

    // Methods from Wrapper

    public final boolean isWrapperFor(Class<?> iface) 
	    throws SQLException
    {
	return pStmt.isWrapperFor(iface);
    }

    public final <T> T unwrap(Class <T> iface) 
	    throws SQLException
    {
	return pStmt.unwrap(iface);
    }
}

