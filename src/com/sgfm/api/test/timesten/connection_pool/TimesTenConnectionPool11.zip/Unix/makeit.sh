#!/bin/bash
cd ..
make -f Unix/Makefile $*
cd Unix
