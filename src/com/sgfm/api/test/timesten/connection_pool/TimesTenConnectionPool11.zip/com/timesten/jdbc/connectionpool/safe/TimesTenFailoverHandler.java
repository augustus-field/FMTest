package com.timesten.jdbc.connectionpool;

import java.sql.*;
import com.timesten.jdbc.*;

/**
 * Represents a Timesten Failover Handler.
 * This class instantiates a TimesTen Failover Handler object.
 */
public final class TimesTenFailoverHandler
		    implements ClientFailoverEventListener
{
    ////////////// PRIVATE DATA /////////////

    // The owning connection pool
    private TimesTenConnectionPool cpool = null;

    ////////////// CONSTRUCTOR /////////////

    TimesTenFailoverHandler(TimesTenConnectionPool pool)
    {
	this.cpool = pool;
    }

    ////////////// FINALIZER /////////////

    protected void finalize()
	    throws Throwable
    {
	this.cpool = null;
	super.finalize();
    }

    ////////////// PUBLIC FUNCTIONS /////////////

    public void notify(ClientFailoverEvent event)
    {
        ClientFailoverEvent.FailoverEvent theEvent = event.getTheFailoverEvent();
        switch (  theEvent  )
        {
	    case BEGIN:
	        cpool.beginFailover();
	        break;
	    case END:
	        cpool.endFailover();
	        break;
	    case ABORT:
	        cpool.abortFailover();
	        break;
        }
    }
}
