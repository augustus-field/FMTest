#!/bin/bash
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:client:TptbmDataCS_tt1121;UID=scott;PWD=tiger" -threads 1 -pool 8 -reads 100 -xacts 100000 -nobuild
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:client:TptbmDataCS_tt1121;UID=scott;PWD=tiger" -threads 2 -pool 8 -reads 100 -xacts 100000 -nobuild
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:client:TptbmDataCS_tt1121;UID=scott;PWD=tiger" -threads 4 -pool 8 -reads 100 -xacts 100000 -nobuild
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:client:TptbmDataCS_tt1121;UID=scott;PWD=tiger" -threads 8 -pool 8 -reads 100 -xacts 100000 -nobuild
