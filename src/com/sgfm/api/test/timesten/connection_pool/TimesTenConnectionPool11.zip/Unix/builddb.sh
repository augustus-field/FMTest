#!/bin/bash
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -build
