#!/bin/bash
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 1 -pool 8 -reads 100 -min 3 -max 3 -xacts 300000 -nobuild
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 2 -pool 8 -reads 100 -min 3 -max 3 -xacts 300000 -nobuild
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 4 -pool 8 -reads 100 -min 3 -max 3 -xacts 300000 -nobuild
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 8 -pool 8 -reads 100 -min 3 -max 3 -xacts 300000 -nobuild
