/**
 * Implements an efficient connection pooling mechanism for the Oracle TimesTen IMDB.
 * This package contains several classes that together provide a
 * very efficient connection pool for use with the Oracle TimesTen IMBD.
 * The main differences between this implementation and the more typical 
 * JDBC connection pool implementations are as follows:
 * <p><p>
 * 1.  This implementation associates statements with the pooled
 *     connections. This obviates the need to rely on driver
 *     or database level statement pooling (which is relatively
 *     inefficient). It does this by eliminating the need for the 
 *     application to prepare all required statements every time it
 *     gets a connection from the pool.
 * <p><p>
 * 2.  It stores the SQL text for the statement, which can be retrieved
 *     later via the getSQL method.
 * <p><p>
 * 3.  It allows for an arbitrary set of optimiser hints to be set for a
 *     statement which will be used when the statement is (re)prepared.
 *     The stored hints can easily be retrieved via the getOptHints()
 *     method.
 * <p><p>
 * 4.  It stores a 'label' for the statement by which it can easily be 
 *     identified. This is used by the application to retrieve the
 *     statements from the connections that it obtains from the pool.
 * <p><p>
 * The typical usage pattern for this connection pool by a multithreaded Java
 * program is as follows:
 * <p><p>
 * Application Initialisation:
 * <p><p>
 * -   Main thread creates one (or more) connection pools with required numbers
 *     of connections and initialises them with DSN and other parameters via
 *     the initialise() method.
 * <p><p>
 * -   Main thread adds all necessary statements (prepared, callable or regular)
 *     to the pool(s) via the various createXXXXStatement() methods:w
 *     .
 * <p><p>
 * -   Main thread enables the pool(s) for use via the enable() method.
 * <p><p>
 * -   Main thread creates other threads, passing them the connection pool(s)
 *     that they should use.
 * <p><p>
 * Secondary thread(s), when performing a database transaction:
 * <p><p>
 * -    Get a free connection from the connection pool via the getConnection()
 *      or getConnectionWait() method.
 * <p><p>
 * -    Obtains the relevant statement objects via the getXXXXStmt() methods.
 * <p><p>
 * -    Executes the statement(s) and processes result sets as normal.
 * <p><p>
 * -    Executes a commit (or rollback) to close the active transaction.
 * <p><p>
 * -    Returns the connection to the pool using the releaseConnection()
 *      method.
 * <p><p>
 * Application termination:
 * <p><p>
 * -    Main thread suspends the connection pool(s) via the suspend() method.
 * <p><p>
 * -    Main thread waits for each pool to become quiescent. This can be
 *      checked via the isQuiescent() method or by using the waitforQuiescent()
 *      method.
 * <p><p>
 * -    Main threads tears down the connection pool(s) using the shutdown()
 *      method.
 * <p><p>
 * Pool management operations:
 * <p><p>
 * While a pool exists and is being used, various management operations can be
 * performed on it. In general, the pool must first be quiesced (suspend()
 * then waitforQuiescent()) before it can be manipulated. After manipulation
 * it must then be enabled again (enable()).
 * <p><p>
 * See createXXXXStmt, removeXXXXStmt() and resizePool() methods for more 
 * details.
 * <p><p>
 * Supports Java 6 and TimesTen 11.2.
 */
package com.timesten.jdbc.connectionpool;
