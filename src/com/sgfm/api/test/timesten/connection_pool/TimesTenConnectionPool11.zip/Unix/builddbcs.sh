#!/bin/bash
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:client:TptbmDataCS_tt1121;UID=scott;PWD=tiger" -build
