#!/bin/bash
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 2 -pool 1 -reads 100 -xacts 100000 -nobuild -testPoolResize 2
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 4 -pool 4 -reads 100 -xacts 100000 -nobuild -testPoolResize 4
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 8 -pool 8 -reads 100 -xacts 100000 -nobuild -testPoolResize 4
java -cp ..:../ttcp.jar:$CLASSPATH TptbmPool -url "jdbc:timesten:direct:TptbmData_tt1121" -threads 16 -pool 4 -reads 100 -xacts 100000 -nobuild -testPoolResize 8
